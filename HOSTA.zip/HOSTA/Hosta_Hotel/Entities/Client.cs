namespace Hosta_Hotel.Entities;

public record Client : Persoana
{
}