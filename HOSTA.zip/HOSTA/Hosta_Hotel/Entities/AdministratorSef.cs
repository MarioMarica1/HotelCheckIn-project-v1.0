namespace Hosta_Hotel.Entities;

public class AdministratorSef
{
    
}