namespace Hosta_Hotel.Entities;

public record Administrator : Persoana
{
}