﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Hosta_Hotel.TheBrain;
using Hosta_Hotel.Infrastructure;
using Hosta_Hotel.Logging;

namespace Hosta_Hotel;

class Program
{
    // "async Task" este standardul modern pentru entry-point
    static async Task Main(string[] args)
    {
        // Construim "Containerul" aplicației (Generic Host)
        using IHost host = Host.CreateDefaultBuilder(args)
            .ConfigureServices((context, services) =>
            {
                // 1. Înregistrarea Serviciilor (Dependency Injection)
                
                // PersistenceManager e Singleton (unul singur pt toata aplicatia)
                services.AddSingleton<PersistenceManager>();
                
                // Hotel (Agregatul) e Singleton pentru că ține starea în memorie
                services.AddSingleton<Hotel>();

                // HotelApp este serviciul care rulează efectiv (Meniul)
                services.AddHostedService<HotelApp>();

                // 2. Configurarea Logging-ului (Să scrie în JSON, nu în consolă)
                services.AddLogging(builder =>
                {
                    // Scoatem logurile default (Console, Debug) ca să nu polueze meniul
                    builder.ClearProviders();
                    
                    // Adăugăm logger-ul nostru custom
                    builder.AddProvider(new JsonFileLoggerProvider("hotel_logs.json"));
                    
                    // Setăm nivelul minim (Information = logăm tot ce e important)
                    builder.SetMinimumLevel(LogLevel.Information);
                });
            })
            .Build();

        // Pornim aplicația și așteptăm să se termine
        await host.RunAsync();
    }
}